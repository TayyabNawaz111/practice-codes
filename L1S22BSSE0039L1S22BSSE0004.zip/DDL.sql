CREATE DATABASE motorhome_rental;

USE motorhome_rental;

CREATE TABLE Customers (
  CustomerID INT PRIMARY KEY,
  FirstName VARCHAR(50),
  LastName VARCHAR(50),
  Email VARCHAR(100),
  PhoneNumber VARCHAR(20),
  Address VARCHAR(100)
);

CREATE TABLE VehicleTypes (
  VehicleTypeID INT PRIMARY KEY,
  TypeName VARCHAR(50),
  Description VARCHAR(100)
);

CREATE TABLE InsuranceProviders (
  InsuranceProviderID INT PRIMARY KEY,
  ProviderName VARCHAR(100),
  ContactPerson VARCHAR(100),
  PhoneNumber VARCHAR(20),
  Email VARCHAR(100)
);

CREATE TABLE Employees (
  EmployeeID INT PRIMARY KEY,
  FirstName VARCHAR(50),
  LastName VARCHAR(50),
  Position VARCHAR(50),
  Email VARCHAR(100),
  PhoneNumber VARCHAR(20)
);

CREATE TABLE MaintenanceServices (
  ServiceID INT PRIMARY KEY,
  Description VARCHAR(100),
  ServiceProvider VARCHAR(100),
  ServiceDate DATE,
  Cost DECIMAL(8, 2)
);

CREATE TABLE Motorhomes (
  MotorhomeID INT PRIMARY KEY,
  Make VARCHAR(50),
  Model VARCHAR(50),
  Year INT,
  Capacity INT,
  DailyRentalRate DECIMAL(8, 2),
  InsuranceProviderID INT,
  VehicleTypeID INT,
  FOREIGN KEY (InsuranceProviderID) REFERENCES InsuranceProviders(InsuranceProviderID),
  FOREIGN KEY (VehicleTypeID) REFERENCES VehicleTypes(VehicleTypeID)
);

CREATE TABLE Rentals (
  RentalID INT PRIMARY KEY,
  StartDate DATE,
  EndDate DATE,
  TotalCost DECIMAL(8, 2),
  CustomerID INT,
  MotorhomeID INT,
  EmployeeID INT,
  FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID),
  FOREIGN KEY (MotorhomeID) REFERENCES Motorhomes(MotorhomeID),
  FOREIGN KEY (EmployeeID) REFERENCES Employees(EmployeeID)
);

CREATE TABLE Reservations (
  ReservationID INT PRIMARY KEY,
  StartDate DATE,
  EndDate DATE,
  CustomerID INT,
  FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);

CREATE TABLE Payments (
  PaymentID INT PRIMARY KEY,
  RentalID INT,
  PaymentDate DATE,
  Amount DECIMAL(8, 2),
  PaymentMethod VARCHAR(50),
  CustomerID INT,
  FOREIGN KEY (RentalID) REFERENCES Rentals(RentalID),
  FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);

CREATE TABLE TripLogs (
  LogID INT PRIMARY KEY,
  StartOdometerReading INT,
  EndOdometerReading INT,
  StartLocation VARCHAR(100),
  EndLocation VARCHAR(100),
  DistanceTraveled INT,
  RentalID INT,
  FOREIGN KEY (RentalID) REFERENCES Rentals(RentalID)
);

CREATE TABLE Can_be_performed (
  MotorhomeID INT,
  ServiceID INT,
  PRIMARY KEY (MotorhomeID, ServiceID),
  FOREIGN KEY (MotorhomeID) REFERENCES Motorhomes(MotorhomeID),
  FOREIGN KEY (ServiceID) REFERENCES MaintenanceServices(ServiceID)
);





