CREATE DATABASE motorhome_rental;

USE motorhome_rental;

CREATE TABLE Customers (
  CustomerID INT PRIMARY KEY,
  FirstName VARCHAR(50),
  LastName VARCHAR(50),
  Email VARCHAR(100),
  PhoneNumber VARCHAR(20),
  Address VARCHAR(100)
);

CREATE TABLE VehicleTypes (
  VehicleTypeID INT PRIMARY KEY,
  TypeName VARCHAR(50),
  Description VARCHAR(100)
);

CREATE TABLE InsuranceProviders (
  InsuranceProviderID INT PRIMARY KEY,
  ProviderName VARCHAR(100),
  ContactPerson VARCHAR(100),
  PhoneNumber VARCHAR(20),
  Email VARCHAR(100)
);

CREATE TABLE Employees (
  EmployeeID INT PRIMARY KEY,
  FirstName VARCHAR(50),
  LastName VARCHAR(50),
  Position VARCHAR(50),
  Email VARCHAR(100),
  PhoneNumber VARCHAR(20)
);

CREATE TABLE MaintenanceServices (
  ServiceID INT PRIMARY KEY,
  Description VARCHAR(100),
  ServiceProvider VARCHAR(100),
  ServiceDate DATE,
  Cost DECIMAL(8, 2)
);

CREATE TABLE Motorhomes (
  MotorhomeID INT PRIMARY KEY,
  Make VARCHAR(50),
  Model VARCHAR(50),
  Year INT,
  Capacity INT,
  DailyRentalRate DECIMAL(8, 2),
  InsuranceProviderID INT,
  VehicleTypeID INT,
  FOREIGN KEY (InsuranceProviderID) REFERENCES InsuranceProviders(InsuranceProviderID),
  FOREIGN KEY (VehicleTypeID) REFERENCES VehicleTypes(VehicleTypeID)
);

CREATE TABLE Rentals (
  RentalID INT PRIMARY KEY,
  StartDate DATE,
  EndDate DATE,
  TotalCost DECIMAL(8, 2),
  CustomerID INT,
  MotorhomeID INT,
  EmployeeID INT,
  FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID),
  FOREIGN KEY (MotorhomeID) REFERENCES Motorhomes(MotorhomeID),
  FOREIGN KEY (EmployeeID) REFERENCES Employees(EmployeeID)
);

CREATE TABLE Reservations (
  ReservationID INT PRIMARY KEY,
  StartDate DATE,
  EndDate DATE,
  CustomerID INT,
  FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);

CREATE TABLE Payments (
  PaymentID INT PRIMARY KEY,
  RentalID INT,
  PaymentDate DATE,
  Amount DECIMAL(8, 2),
  PaymentMethod VARCHAR(50),
  CustomerID INT,
  FOREIGN KEY (RentalID) REFERENCES Rentals(RentalID),
  FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);

CREATE TABLE TripLogs (
  LogID INT PRIMARY KEY,
  StartOdometerReading INT,
  EndOdometerReading INT,
  StartLocation VARCHAR(100),
  EndLocation VARCHAR(100),
  DistanceTraveled INT,
  RentalID INT,
  FOREIGN KEY (RentalID) REFERENCES Rentals(RentalID)
);

CREATE TABLE Can_be_performed (
  MotorhomeID INT,
  ServiceID INT,
  PRIMARY KEY (MotorhomeID, ServiceID),
  FOREIGN KEY (MotorhomeID) REFERENCES Motorhomes(MotorhomeID),
  FOREIGN KEY (ServiceID) REFERENCES MaintenanceServices(ServiceID)
);



INSERT INTO Customers (CustomerID, FirstName, LastName, Email, PhoneNumber, Address)
VALUES
  (1, 'Ahmed', 'Khan', 'ahmed.khan@example.com', '+92 300 1111111', '123 Main Street, Lahore'),
  (2, 'Fatima', 'Ali', 'fatima.ali@example.com', '+92 321 2222222', '456 Park Avenue, Karachi'),
  (3, 'Mohammad', 'Hussain', 'mohammad.hussain@example.com', '+92 333 3333333', '789 Bazaar Road, Islamabad'),
  (4, 'Aisha', 'Ahmed', 'aisha.ahmed@example.com', '+92 300 4444444', '567 Garden Lane, Lahore'),
  (5, 'Imran', 'Khan', 'imran.khan@example.com', '+92 321 5555555', '890 City Road, Karachi'),
  (6, 'Saima', 'Akhtar', 'saima.akhtar@example.com', '+92 333 6666666', '123 River View, Islamabad'),
  (7, 'Tariq', 'Ali', 'tariq.ali@example.com', '+92 300 7777777', '456 Hillside Avenue, Lahore'),
  (8, 'Nadia', 'Hussain', 'nadia.hussain@example.com', '+92 321 8888888', '789 Valley Road, Karachi'),
  (9, 'Ahmed', 'Khalid', 'ahmed.khalid@example.com', '+92 333 9999999', '123 Forest Street, Islamabad'),
  (10, 'Sana', 'Khan', 'sana.khan@example.com', '+92 300 0000000', '456 Ocean View, Lahore');

INSERT INTO VehicleTypes (VehicleTypeID, TypeName, Description)
VALUES
  (1, 'Car', 'Four-wheeled motor vehicle'),
  (2, 'Motorcycle', 'Two-wheeled motor vehicle'),
  (3, 'SUV', 'Sport Utility Vehicle'),
  (4, 'Truck', 'Large transport vehicle'),
  (5, 'Van', 'Multi-purpose passenger van'),
  (6, 'Bus', 'Large passenger-carrying vehicle'),
  (7, 'RV', 'Recreational Vehicle'),
  (8, 'Crossover', 'Combination of SUV and Sedan'),
  (9, 'Convertible', 'Open-top car'),
  (10, 'Hatchback', 'Compact car with a rear door that opens upwards');

INSERT INTO InsuranceProviders (InsuranceProviderID, ProviderName, ContactPerson, PhoneNumber, Email)
VALUES
  (1, 'ABC Insurance', 'John Doe', '+92 300 1111111', 'john.doe@abcinsurance.com'),
  (2, 'XYZ Insurance', 'Jane Smith', '+92 321 2222222', 'jane.smith@xyzinsurance.com'),
  (3, 'PakSure Insurance', 'Ali Khan', '+92 333 3333333', 'ali.khan@paksureinsurance.com'),
  (4, 'SafeGuard Insurance', 'Sara Ahmed', '+92 300 4444444', 'sara.ahmed@safeguardinsurance.com'),
  (5, 'QuickCover Insurance', 'Muhammad Iqbal', '+92 321 5555555', 'muhammad.iqbal@quickcoverinsurance.com'),
  (6, 'SecureLife Insurance', 'Ayesha Malik', '+92 333 6666666', 'ayesha.malik@securelifeinsurance.com'),
  (7, 'ReliableInsure Insurance', 'Ahmed Khan', '+92 300 7777777', 'ahmed.khan@reliableinsureinsurance.com'),
  (8, 'PrimeShield Insurance', 'Nadia Ali', '+92 321 8888888', 'nadia.ali@primeshieldinsurance.com'),
  (9, 'TrustSure Insurance', 'Hassan Raza', '+92 333 9999999', 'hassan.raza@trustsureinsurance.com'),
  (10, 'GlobalCover Insurance', 'Sana Khan', '+92 300 0000000', 'sana.khan@globalcoverinsurance.com');


INSERT INTO Employees (EmployeeID, FirstName, LastName, Position, Email, PhoneNumber)
VALUES
  (1, 'Ahmed', 'Khan', 'Manager', 'ahmed.khan@example.com', '+92 300 1111111'),
  (2, 'Fatima', 'Ali', 'Supervisor', 'fatima.ali@example.com', '+92 321 2222222'),
  (3, 'Aamir', 'Hussain', 'Sales Executive', 'aamir.hussain@example.com', '+92 333 3333333'),
  (4, 'Sana', 'Ahmed', 'Customer Service Representative', 'sana.ahmed@example.com', '+92 300 4444444'),
  (5, 'Imran', 'Khan', 'Technician', 'imran.khan@example.com', '+92 321 5555555'),
  (6, 'Zara', 'Akhtar', 'Accountant', 'zara.akhtar@example.com', '+92 333 6666666'),
  (7, 'Tariq', 'Ali', 'Driver', 'tariq.ali@example.com', '+92 300 7777777'),
  (8, 'Nadia', 'Hussain', 'Cleaner', 'nadia.hussain@example.com', '+92 321 8888888'),
  (9, 'Hassan', 'Khalid', 'Security Guard', 'hassan.khalid@example.com', '+92 333 9999999'),
  (10, 'Sara', 'Khan', 'Assistant Manager', 'sara.khan@example.com', '+92 300 0000000');


INSERT INTO MaintenanceServices (ServiceID, Description, ServiceProvider, ServiceDate, Cost)
VALUES
  (1, 'Oil Change', 'Car Care Center', '2023-06-01', 5000),
  (2, 'Tire Rotation', 'Auto Repair Shop', '2023-06-02', 2000),
  (3, 'Brake Inspection', 'Mechanic Garage', '2023-06-03', 1500),
  (4, 'Air Filter Replacement', 'Car Service Station', '2023-06-04', 1000),
  (5, 'Battery Check', 'Auto Shop', '2023-06-05', 800),
  (6, 'Wheel Alignment', 'Tire Service Center', '2023-06-06', 2500),
  (7, 'Coolant Flush', 'Radiator Specialist', '2023-06-07', 3000),
  (8, 'Spark Plug Replacement', 'Engine Repair Workshop', '2023-06-08', 1200),
  (9, 'Transmission Fluid Change', 'Transmission Specialist', '2023-06-09', 3500),
  (10, 'Engine Tune-Up', 'Auto Service Center', '2023-06-10', 4000);


INSERT INTO Motorhomes (MotorhomeID, Make, Model, Year, Capacity, DailyRentalRate, InsuranceProviderID, VehicleTypeID)
VALUES
  (1, 'Toyota', 'Hiace', 2021, 6, 5000, 1, 7),
  (2, 'Mercedes-Benz', 'Sprinter', 2022, 4, 6000, 2, 7),
  (3, 'Volkswagen', 'California', 2020, 4, 5500, 3, 7),
  (4, 'Ford', 'Transit', 2023, 6, 4800, 4, 7),
  (5, 'Chevrolet', 'Express', 2021, 8, 5500, 5, 7),
  (6, 'Winnebago', 'Travato', 2022, 2, 4500, 6, 7),
  (7, 'Airstream', 'Interstate', 2020, 4, 6500, 7, 7),
  (8, 'Jayco', 'Redhawk', 2023, 6, 5200, 8, 7),
  (9, 'Coachmen', 'Mirada', 2021, 6, 4800, 9, 7),
  (10, 'Thor Motor Coach', 'Chateau', 2022, 8, 6000, 10, 7);


INSERT INTO Rentals (RentalID, CustomerID, MotorhomeID, StartDate, EndDate, TotalCost, EmployeeID)
VALUES
  (1, 1, 3, '2023-07-01', '2023-07-07', 35000, 1),
  (2, 2, 5, '2023-07-02', '2023-07-05', 16500, 2),
  (3, 3, 1, '2023-07-03', '2023-07-09', 42000, 3),
  (4, 4, 7, '2023-07-05', '2023-07-10', 39000, 4),
  (5, 5, 2, '2023-07-07', '2023-07-12', 30000, 5),
  (6, 6, 9, '2023-07-10', '2023-07-15', 36000, 6),
  (7, 7, 4, '2023-07-12', '2023-07-18', 42000, 7),
  (8, 8, 6, '2023-07-15', '2023-07-20', 27000, 8),
  (9, 9, 10, '2023-07-18', '2023-07-23', 35000, 9),
  (10, 10, 8, '2023-07-20', '2023-07-25', 30000, 10);


INSERT INTO Reservations (ReservationID, CustomerID, StartDate, EndDate)
VALUES
  (1, 1, '2023-07-15', '2023-07-20'),
  (2, 2, '2023-07-18', '2023-07-25'),
  (3, 3, '2023-07-20', '2023-07-26'),
  (4, 4, '2023-07-23', '2023-07-30'),
  (5, 5, '2023-07-25', '2023-08-01'),
  (6, 6, '2023-07-28', '2023-08-04'),
  (7, 7, '2023-07-30', '2023-08-06'),
  (8, 8, '2023-08-02', '2023-08-08'),
  (9, 9, '2023-08-05', '2023-08-12'),
  (10, 10, '2023-08-08', '2023-08-15');


INSERT INTO Payments (PaymentID, RentalID, PaymentDate, Amount, PaymentMethod, CustomerID)
VALUES
  (1, 1, '2023-07-05', 10000, 'Credit Card', 1),
  (2, 2, '2023-07-10', 7500, 'Cash', 2),
  (3, 3, '2023-07-12', 15000, 'Credit Card', 3),
  (4, 4, '2023-07-15', 12000, 'Cheque', 4),
  (5, 5, '2023-07-20', 9000, 'Credit Card', 5),
  (6, 6, '2023-07-25', 11000, 'Cash', 6),
  (7, 7, '2023-07-28', 16000, 'Credit Card', 7),
  (8, 8, '2023-07-30', 8000, 'Cheque', 8),
  (9, 9, '2023-08-04', 13000, 'Credit Card', 9),
  (10, 10, '2023-08-08', 10000, 'Cash', 10);


INSERT INTO TripLogs (LogID, RentalID, StartOdometerReading, EndOdometerReading, StartLocation, EndLocation, DistanceTraveled)
VALUES
  (1, 1, 5000, 5500, 'Lahore', 'Islamabad', 500),
  (2, 2, 3200, 3700, 'Karachi', 'Hyderabad', 500),
  (3, 3, 7000, 7500, 'Islamabad', 'Lahore', 500),
  (4, 4, 4200, 4700, 'Rawalpindi', 'Peshawar', 500),
  (5, 5, 2500, 3000, 'Faisalabad', 'Lahore', 500),
  (6, 6, 5800, 6300, 'Multan', 'Bahawalpur', 500),
  (7, 7, 4700, 5200, 'Gujranwala', 'Sialkot', 500),
  (8, 8, 3900, 4400, 'Quetta', 'Sukkur', 500),
  (9, 9, 5300, 5800, 'Gwadar', 'Turbat', 500),
  (10, 10, 3500, 4000, 'Abbottabad', 'Muzaffarabad', 500);
  


INSERT INTO Can_be_performed (MotorhomeID, ServiceID)
VALUES
  (1, 3),
  (2, 4),
  (3, 5),
  (4, 1),
  (5, 2),
  (6, 6),
  (7, 10),
  (8, 8),
  (9, 9),
  (10, 7);




UPDATE TripLogs
SET DistanceTraveled = 700
WHERE LogID = 3; 

UPDATE Customers
SET PhoneNumber = '9876543210'
WHERE CustomerID = 1;


UPDATE Reservations
SET EndDate = '2023-07-22'
WHERE ReservationID = 3;


UPDATE Motorhomes
SET DailyRentalRate = 12000
WHERE MotorhomeID = 5;


UPDATE Payments
SET Amount = 9500
WHERE PaymentID = 2;


UPDATE Rentals
SET TotalCost = 15000
WHERE RentalID = 4;


/* 	      JOINS         */
/*  1 Retrieve the rental details (RentalID, StartDate, EndDate) along with the customer's first name and last name
 (FirstName, LastName) for all rentals that involve motorhomes provided by the insurance provider 'SecureLife Insurance'.  */


SELECT r.RentalID, r.StartDate, r.EndDate, c.FirstName, c.LastName
FROM Rentals r
INNER JOIN motorhomes m ON r.MotorhomeID = m.MotorhomeID
INNER JOIN InsuranceProviders ip ON m.InsuranceProviderID = ip.InsuranceProviderID
INNER JOIN customers c ON r.CustomerID = c.CustomerID
WHERE ip.ProviderName = 'SecureLife Insurance';

/*  RIGHT JOIN
"Retrieve the information about rentals and their associated customers, motorhomes, 
and employees,( including rentals that have no corresponding customer entry.) Display the rental ID, 
customer information, motorhome information, and employee information for all rentals."*/

SELECT *
FROM Rentals r
RIGHT JOIN Customers c ON r.CustomerID = c.CustomerID
RIGHT JOIN Payments p ON r.RentalID = p.RentalID
RIGHT JOIN Employees e ON r.EmployeeID = e.EmployeeID;

/*LEFT JOIN
retrieve information about customers, their rentals, the motorhomes
 they rented, and the employees associated with those rentals

*/


SELECT C.CustomerID, C.FirstName, C.LastName, R.RentalID, M.Make, M.Model, E.FirstName, E.LastName
FROM Customers C
LEFT JOIN Rentals R ON C.CustomerID = R.CustomerID
LEFT JOIN Motorhomes M ON R.MotorhomeID = M.MotorhomeID
LEFT JOIN Employees E ON R.EmployeeID = E.EmployeeID;

/* SUBQUERIES  */
/*
Retrieve the motorhome IDs
that have been rented by customers who have made payments using  Credit Card insurance is provided by PakSure Insurance

*/
SELECT  m.MotorhomeID
FROM Motorhomes m
WHERE MotorhomeID IN (
    SELECT r.MotorhomeID
    FROM Rentals r
    WHERE RentalID IN (
        SELECT RentalID
        FROM Payments
        WHERE PaymentMethod = 'Credit Card'
    )
    AND m.InsuranceProviderID IN(
    SELECT ip.InsuranceProviderID
    FROM insuranceproviders ip
    WHERE ip.ProviderName='PakSure Insurance'
    )
);

/*
 retrieve the first name, last name, start date, and end date of rentals for customers
 who have made payments with amounts greater than the average amount of all payments and 
 treated by the employee who has empID=9

*/

SELECT c.FirstName, c.LastName, r.StartDate, r.EndDate,r.employeeID
FROM Customers c, Rentals  r
WHERE c.CustomerID = r.CustomerID
  AND r.RentalID IN (
    SELECT p.RentalID
    FROM Payments  p
    WHERE p.Amount > (
      SELECT AVG(Amount)
      FROM Payments
    )
    AND r.employeeID IN(
    SELECT EmployeeID FROM employees
    WHERE EmployeeID  = 9
    )
  );

/*
retrieve the first and last names of customers who have rented a motorhome for a trip 
where the distance traveled was more than 500 units and paid amount by Credit Card

*/


SELECT FirstName, LastName
FROM Customers
WHERE CustomerID IN (
  SELECT CustomerID
  FROM Rentals
  WHERE RentalID IN (
    SELECT RentalID
    FROM TripLogs
    WHERE DistanceTraveled > 500
  )
  AND CustomerID IN(
	SELECT CustomerID FROM payments 
    WHERE PaymentMethod='Credit Card'
  )
);



