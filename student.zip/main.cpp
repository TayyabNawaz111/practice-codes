#include "dataStructures.h"
#include "student.h"
#include <fstream>
#include <sstream>
const string filename = "data.txt";
//functions
// Function to write data to file
void writeDataToFile(string filename, vector<Student> &students) {
	ofstream file;
	file.open(filename, ios::trunc);
	if (file.is_open()) {
		for (auto student : students) {
			file << student.lastName << ',' << student.firstName << ' ' << student.middleInitial << ';'
				<< student.key << ';' << student.major << ';' << student.year << ';'
				<< student.email << ';' << student.homePhone << ';' << student.workPhone << '\n';
		}
		file.close();
	}
}

// Function to delete a record by key
bool deleteRecord(vector<Student> &students, string key) {
	for (auto i = students.begin(); i != students.end(); i++){
		if (i->key == key){
			students.erase(i);
			writeDataToFile(filename, students);
			return true;
		}
	}
	cout << "Record not found.\n";
	return false;
}
// Function to insert/change email address for a record
void InsertorChangeEmail(vector<Student> &students, string key, string newEmail) {
	for (auto &student : students) {
		if (student.key == key) {
			student.email = newEmail;
			/*cout << student.email << endl;
			cout << "--------------------\n";*/
			writeDataToFile(filename, students);
			cout << "Email updated successfully.\n";
			return;
		}
	}
	cout << "Record not found.\n";
}
// Function to read data from file 
vector<Student> readDataFromFile(string filename) {
	vector<Student> students;
	ifstream file(filename);

	if (file.is_open()) {
		string line;
		while (getline(file, line)) {
			stringstream ss(line);
			Student student;

			getline(ss, student.lastName, ',');
			getline(ss, student.firstName, ' ');
			getline(ss, student.middleInitial, ';');
			getline(ss, student.key, ';');
			getline(ss, student.major, ';');
			getline(ss, student.year, ';');
			getline(ss, student.email, ';');
			getline(ss, student.homePhone, ';');
			getline(ss, student.workPhone, ';');

			students.push_back(student);
		}
		file.close();
	}

	return students;
}


// Function to display all student records
void displayAllRecords(vector<Student> &students) {
	for (auto student : students) {
		student.displayRecord();
	}
}




// Function to write all student records in sorted order
void writeSortedDataToFile(string filename, vector<Student> &students) {
	vector<Student> sortedStudents = students;
	for (int i = 0; i < sortedStudents.size(); i++) {
		for (int j = i + 1; j < sortedStudents.size(); j++) {
			if (sortedStudents[i].key > sortedStudents[j].key) {
				swap(sortedStudents[i], sortedStudents[j]);
			}
		}
	}
	writeDataToFile(filename, sortedStudents);
	cout << "Records written to file in sorted order.\n";
}

// Function to insert/change home phone number for a record
void UpdateHomePhone(vector<Student> &students, string key, string newHomePhone) {
	for (auto &student : students) {
		if (student.key == key) {
			student.homePhone = newHomePhone;
			cout << "Home phone number updated successfully.\n";
			writeDataToFile(filename, students);
			return;
		}
	}
	cout << "Record not found.\n";
}

// Function to insert/change a record in the directory
void AddorUpdateRecord(vector<Student> &students, Student newStudent) {
	for (auto student : students) {
		if (student.key == newStudent.key) {
			student = newStudent;
			cout << "Record updated successfully.\n";
			writeDataToFile(filename, students);
			return;
		}
	}
	students.push_back(newStudent);
	writeDataToFile(filename, students);
	cout << "Record inserted successfully.\n";
}

//print specific record
void displaySpecificRecord(vector<Student> &students, string key) {
	for (auto student : students) {
		if (student.key == key) {
			cout << "Record found:\n";
			student.displayRecord();
			return;
		}
	}
	cout << "Record not found.\n";
}

// work phone insertion/updation
void UpdateWorkPhone(vector<Student> &students, string key, string newWorkPhone) {
	for (auto &student : students) {
		if (student.key == key) {
			student.workPhone = newWorkPhone;
			cout << "Work phone number updated successfully.\n";
			writeDataToFile(filename, students);
			return;
		}
	}
	cout << "Record not found.\n";
}




int main()
{
	int enter;
	cout << "Press 1 for Vectors: ";
	cin >> enter;
	if (enter == 1){
		//first of all read data from file
		vector<Student>students = readDataFromFile(filename);


		int choice;
		string key;

		do {
			// Display the menu
			cout << "Menu:\n";
			cout << "1) Delete a record\n"; //done
			cout << "2) update email address\n"; //done
			cout << "3) Write all records in file(sorted)\n"; //done
			cout << "4) update home phone\n"; //done
			cout << "5) Add/update record\n";//done
			cout << "6) Print specific record\n"; //done
			cout << "7) Print all students\n"; //done
			cout << "8) update Work phone\n"; //done
			cout << "9) Quit\n";
			cout << "Enter your choice: ";
			cin >> choice;

			if (choice == 1) {
				cout << "Enter KEY for deletion: ";
				cin >> key;
				if (deleteRecord(students, key)){
					cout << "After deletion records are:\n";
					displayAllRecords(students);
				}

			}
			else if (choice == 2) {
				cout << "Enter KEY for email update: ";
				cin.ignore();
				cin >> key;
				string newEmail;
				cout << "Enter new email: ";
				cin.ignore();
				getline(cin, newEmail);
				InsertorChangeEmail(students, key, newEmail);
			}
			else if (choice == 3) {
				writeSortedDataToFile(filename, students);
			}
			else if (choice == 4) {
				cout << "Enter KEY for Home phone update: ";
				cin.ignore();
				cin >> key;
				string newHomePhone;
				cout << "Enter new phone number: ";
				cin.ignore();
				getline(cin, newHomePhone);
				UpdateHomePhone(students, key, newHomePhone);
			}
			else if (choice == 5) {
				string lastName;
				string firstName;
				string middleInitial;
				string key;
				string major;
				string year;
				string email;
				string homePhone;
				string workPhone;
				cout << "Enter Last name: ";
				cin.ignore();
				getline(cin, lastName);
				cout << "Enter First name: ";
				cin.ignore();
				getline(cin, firstName);
				cout << "Enter Middle Initial: ";
				cin.ignore();
				getline(cin, middleInitial);
				cout << "Enter key: ";
				cin.ignore();
				getline(cin, key);
				cout << "Enter Major: ";
				cin.ignore();
				getline(cin, major);
				cout << "Enter year: ";
				cin.ignore();
				getline(cin, year);
				cout << "Enter email: ";
				cin.ignore();
				getline(cin, email);
				cout << "Enter Home phone: ";
				cin.ignore();
				getline(cin, homePhone);
				cout << "Enter work phone: ";
				cin.ignore();
				getline(cin, workPhone);
				Student newStudent(lastName, firstName, middleInitial, key, major, year, email, homePhone, workPhone);
				AddorUpdateRecord(students, newStudent);
			}
			else if (choice == 6) {
				cout << "Enter KEY for display: ";
				cin >> key;
				displaySpecificRecord(students, key);
			}
			else if (choice == 7) {
				displayAllRecords(students);
			}
			else if (choice == 8) {
				cout << "Enter KEY for work phone update: ";
				cin >> key;
				string workPhone;
				cout << "Enter work phone: ";
				cin.ignore();
				getline(cin, workPhone);
				UpdateWorkPhone(students,key, workPhone);

			}
			else if (choice == 9) {
				cout << "Quitting....\n";

			}
			else {
				cout << "Invalid choice. Try again.\n";
			}

		} while (choice != 9);
	}
//else if(enter==2){
//	LinkedList<Student> studentList;
//	studentList.readDataFromFile();
//
//	int choice;
//	string key;
//
//	do {
//		// Display the menu
//		cout << "Menu:\n";
//		cout << "1) Delete a record\n";
//		cout << "2) Update email address\n";
//		cout << "3) Write all records in file (sorted)\n";
//		cout << "4) Update home phone\n";
//		cout << "5) Add/update record\n";
//		cout << "6) Print specific record\n";
//		cout << "7) Print all students\n";
//		cout << "8) Update work phone\n";
//		cout << "9) Quit\n";
//		cout << "Enter your choice: ";
//		cin >> choice;
//
//		if (choice == 1) {
//			cout << "Enter KEY for deletion: ";
//			cin >> key;
//			if (studentList.deleteRecord(key)) {
//				cout << "After deletion records are:\n";
//				studentList.displayAllRecords();
//			}
//		}
//		else if (choice == 2) {
//			cout << "Enter KEY for email update: ";
//			cin >> key;
//			string newEmail;
//			cout << "Enter new email: ";
//			cin.ignore();
//			getline(cin, newEmail);
//			studentList.insertOrChangeEmail(key, newEmail);
//		}
//		else if (choice == 3) {
//			studentList.sortList();
//			studentList.writeDataToFile(filename);
//			cout << "Records written to file in sorted order.\n";
//		}
//		else if (choice == 4) {
//			cout << "Enter KEY for Home phone update: ";
//			cin >> key;
//			string newHomePhone;
//			cout << "Enter new phone number: ";
//			cin.ignore();
//			getline(cin, newHomePhone);
//			studentList.updateHomePhone(key, newHomePhone);
//		}
//		else if (choice == 5) {
//			string lastName, firstName, middleInitial, key, major, year, email, homePhone, workPhone;
//			cout << "Enter Last name: ";
//			cin.ignore();
//			getline(cin, lastName);
//			cout << "Enter First name: ";
//			getline(cin, firstName);
//			cout << "Enter Middle Initial: ";
//			getline(cin, middleInitial);
//			cout << "Enter key: ";
//			getline(cin, key);
//			cout << "Enter Major: ";
//			getline(cin, major);
//			cout << "Enter year: ";
//			getline(cin, year);
//			cout << "Enter email: ";
//			getline(cin, email);
//			cout << "Enter Home phone: ";
//			getline(cin, homePhone);
//			cout << "Enter work phone: ";
//			getline(cin, workPhone);
//			Student newStudent(lastName, firstName, middleInitial, key, major, year, email, homePhone, workPhone);
//			studentList.addOrUpdateRecord(newStudent);
//		}
//		else if (choice == 6) {
//			cout << "Enter KEY for display: ";
//			cin >> key;
//			studentList.displaySpecificRecord(key);
//		}
//		else if (choice == 7) {
//			studentList.displayAllRecords();
//		}
//		else if (choice == 8) {
//			cout << "Enter KEY for work phone update: ";
//			cin >> key;
//			string workPhone;
//			cout << "Enter work phone: ";
//			cin.ignore();
//			getline(cin, workPhone);
//			studentList.updateWorkPhone(key, workPhone);
//		}
//		else if (choice == 9) {
//			cout << "Quitting....\n";
//		}
//		else {
//			cout << "Invalid choice. Try again.\n";
//		}
//
//	} while (choice != 9);
//
//}
else{
	cout << "Wrong choice\n";
}
	system("pause");
	return 0;
}