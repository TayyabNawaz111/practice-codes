#ifndef DATA_STRUCTURES_H
#define DATA_STRUCTURES_H
#include "student.h"
#include <iostream>
#include <vector>
#include <string>
using namespace std;
template <typename T>
class Array {
private:
	T* a;
	int size;  // total size
	int length_used;  // used size
	int current;  // current marker

	// Utility Functions
	bool next();  // moves current to the next index
	bool back();  // moves current to the previous index

public:
	//---------Given Functions------------
	Array();
	Array(int s);
	Array(T* d, int s);
	~Array();
	void insertAtStart(T num);
	void insertAtEnd(T num);
	void deleteFromStart();
	void deleteFromEnd();
	bool resize(int s);
	void print();  // prints the complete list
	T get();  // returns the value at the current marker
	int get_curr();  // returns the location of the current marker
};

template <typename T>
class ListNode {
public:
	T data;
	ListNode* next;
	ListNode(T value);
};

template <typename T>
class LinkedList {
	ListNode<T>* head;

public:
	LinkedList();
	void insertAtStart(T value);
	void insertAtEnd(T value);
	void display();
	void deleteNode(T value);
	ListNode<T>* searchNode(T value);
	void addData(T data);
	void insertOrChangeEmail(const string& key, const string& newEmail);
	bool deleteRecord(const string& key);

	void insertOrChangeEmail(string& key, string& newEmail);

	void readDataFromFile();

	void displayAllRecords();

	void writeDataToFile(string filename);

	void sortList();

	void clearList();

	void addOrUpdateRecord(T newStudent);
	void displaySpecificRecord(const string& key);
	void updateHomePhone(const string& key, const string& newHomePhone);
	void updateWorkPhone(const string& key, const string& newWorkPhone);


};

template <typename T>
Array<T>::Array() : a(nullptr), size(0), length_used(0), current(-1) {}

template <typename T>
Array<T>::Array(int s) : size(s), length_used(0), current(-1) {
	a = new T[size];
	for (int i = 0; i < size; i++) {
		a[i] = T();  // Use default constructor for each element
	}
}

template <typename T>
Array<T>::Array(T* d, int s) : size(s), length_used(s), current(-1) {
	a = new T[size];
	for (int i = 0; i < size; i++) {
		a[i] = d[i];
	}
}

template <typename T>
Array<T>::~Array() {
	delete[] a;
}
// Given Functions
template <typename T>
void Array<T>::insertAtStart(T num) {
	if (length_used == size) {
		resize(size * 2);
	}

	for (int i = length_used; i > 0; i--) {
		a[i] = a[i - 1];
	}
	a[0] = num;
	length_used++;
	current = 0;
}

template <typename T>
void Array<T>::insertAtEnd(T num) {
	if (length_used == size) {
		resize(size * 2);
	}

	a[length_used] = num;
	length_used++;
	current = length_used - 1;
}

template <typename T>
void Array<T>::deleteFromStart() {
	if (length_used > 0) {
		for (int i = 0; i < length_used - 1; i++) {
			a[i] = a[i + 1];
		}
		length_used--;
		current = -1;
	}
}

template <typename T>
void Array<T>::deleteFromEnd() {
	if (length_used > 0) {
		length_used--;
		current = -1;
	}
}

template <typename T>
bool Array<T>::resize(int new_size) {
	if (new_size <= 0) {
		return false;
	}

	T* new_array = new T[new_size];

	// Copy elements from the old array to the new array
	for (int i = 0; i < length_used; i++) {
		new_array[i] = a[i];
	}

	// Insert 0 at unused index
	for (int i = length_used; i < size; i++) {
		new_array[i] = T();
	}

	// Delete the old array
	delete[] a;

	a = new_array;
	size = new_size;

	return true;
}

// Extra Helper Functions
template <typename T>
void Array<T>::print() {
	for (int i = 0; i < length_used; i++) {
		cout << a[i] << " ";
	}
	cout << endl;
}

template <typename T>
T Array<T>::get() {
	if (current >= 0  current < length_used) {
		return a[current];
	}
	return T();
}

template <typename T>
int Array<T>::get_curr() {
	return current;
}

template <typename T>
bool Array<T>::next() {
	if (current < length_used - 1) {
		current++;
		return true;
	}
	else {
		return false;
	}
}

template <typename T>
bool Array<T>::back() {
	if (current > 0) {
		current--;
		return true;
	}
	else {
		return false;
	}
}

template <typename T>
ListNode<T>::ListNode(T value) : data(value), next(nullptr) {}

template <typename T>
LinkedList<T>::LinkedList() : head(nullptr) {}

template <typename T>
void LinkedList<T>::insertAtStart(T value) {
	ListNode<T>* newNode = new ListNode<T>(value);
	newNode->next = head;
	head = newNode;
}

template <typename T>
void LinkedList<T>::insertAtEnd(T value) {
	ListNode<T>* newNode = new ListNode<T>(value);
	if (head == nullptr) {
		head = newNode;
		return;
	}
	ListNode<T>* temp = head;
	while (temp->next != nullptr) {
		temp = temp->next;
	}
	temp->next = newNode;
}
template<typename T>
void LinkedList<T>::displaySpecificRecord(const string& key) {
	ListNode<T>* current = head;

	while (current != nullptr) {
		if (current->data.getKey() == key) {
			cout << "Record found:\n";
			current->data.displayRecord();  
			return;
		}

		current = current->next;
	}

	cout << "Record not found.\n";
}


template <typename T>
void LinkedList<T>::addData(T data) {
	ListNode<T>* newNode = new ListNode<T>(data);
	newNode->next = head;
	head = newNode;
}
template <typename T>
bool LinkedList<T>::deleteRecord(const string& key) {
	ListNode<T>* current = head;
	ListNode<T>* prev = nullptr;

	while (current != nullptr) {
		if (current->data.getKey() == key) {
			if (prev != nullptr) {
				prev->next = current->next;
			}
			else {
				head = current->next;
			}

			delete current;
			writeDataToFile("data.txt");
			return true;
		}

		prev = current;
		current = current->next;
	}

	cout << "Record not found.\n";
	return false;
}

template <typename T>
void LinkedList<T>::updateWorkPhone(const string& key, const string& newWorkPhone) {
	ListNode<T>* current = head;

	while (current != nullptr) {
		if (current->data.getKey() == key) {
			current->data.setWorkPhone(newWorkPhone);
			cout << "Work phone number updated successfully.\n";
			writeDataToFile("data.txt");
			return;
		}

		current = current->next;
	}

	cout << "Record not found.\n";
}

template <typename T>
void LinkedList<T>::insertOrChangeEmail(const string& key, const string& newEmail) {
	ListNode<T>* current = head;

	while (current != nullptr) {
		if (current->data.getKey() == key) {
			current->data.setEmail(newEmail);
			writeDataToFile("data.txt");
			cout << "Email updated successfully.\n";
			return;
		}

		current = current->next;
	}

	cout << "Record not found.\n";
}

template <typename T>
void LinkedList<T>::updateHomePhone(const string& key, const string& newHomePhone) {
	ListNode<T>* current = head;

	while (current != nullptr) {
		if (current->data.getKey() == key) {
			current->data.setHomePhone(newHomePhone);
			cout << "Home phone number updated successfully.\n";
			writeDataToFile("data.txt");
			return;
		}

		current = current->next;
	}

	cout << "Record not found.\n";
}

template <typename T>

void readDataFromFile() {
	ifstream file("data.txt");

	if (file.is_open()) {
		clearList(); // Clear existing data

		string line;
		while (getline(file, line)) {
			stringstream ss(line);
			T data;
			ss >> data; 

			addData(data);
		}

		file.close();
	}
}
template <typename T>

void displayAllRecords() {
	ListNode<T>* current = head;

	while (current != nullptr) {
		cout << current->data << endl; 
		current = current->next;
	}
}
template <typename T>

void writeDataToFile(string filename) {
	ofstream file;
	file.open(filename, ios::trunc);

	if (file.is_open()) {
		ListNode<T>* current = head;

		while (current != nullptr) {
			file << current->data << "\n";
			current = current->next;
		}

		file.close();
	}
}
template<typename T>
void LinkedList<T>::addOrUpdateRecord(T newStudent) {
	ListNode<T>* current = head;

	// Search for the student with the same key
	while (current != nullptr) {
		if (current->data.getKey() == newStudent.getKey()) {
			// If found, update the existing record
			current->data = newStudent;
			cout << "Record updated successfully.\n";
			writeDataToFile(filename);
			return;
		}

		current = current->next;
	}

	// If not found, add the new record to the list
	addData(newStudent);
	cout << "Record inserted successfully.\n";
}

template <typename T>

void sortList() {
	if (head == nullptr || head->next == nullptr) {
		return;
	}

	bool swapped;
	ListNode<T>* current;
	ListNode<T>* lastSorted = nullptr;

	do {
		swapped = false;
		current = head;

		while (current->next != lastSorted) {
			if (current->data.getKey() > current->next->data.getKey()) {
				T temp = current->data;
				current->data = current->next->data;
				current->next->data = temp;
				swapped = true;
			}

			current = current->next;
		}

		lastSorted = current;

	} while (swapped);
}
template <typename T>

void clearList() {
	ListNode<T>* current = head;

	while (current != nullptr) {
		ListNode<T>* temp = current;
		current = current->next;
		delete temp;
	}

	head = nullptr;
}
template <typename T>
void LinkedList<T>::display() {
	ListNode<T>* temp = head;
	while (temp != nullptr) {
		cout << "Data: " << temp->data << endl;
		temp = temp->next;
	}
}

template <typename T>
void LinkedList<T>::deleteNode(T value) {
	ListNode<T>* temp = head;
	ListNode<T>* previous = nullptr;

	while (temp != nullptr  temp->data != value) {
		previous = temp;
		temp = temp->next;
	}

	if (temp == nullptr) {
		cout << "ListNode with data " << value << " not found." << endl;
		return;
	}

	if (previous == nullptr) {
		head = temp->next;
	}
	else {
		previous->next = temp->next;
	}

	delete temp;
	cout << "ListNode with data " << value << " deleted." << endl;
}

template <typename T>
ListNode<T>* LinkedList<T>::searchNode(T value) {
	ListNode<T>* temp = head;

	while (temp != nullptr) {
		if (temp->data == value) {
			cout << "ListNode with data " << value << " found" << endl;
			return temp;
		}
		temp = temp->next;
	}

	cout << "ListNode with data " << value << " not found." << endl;
	return nullptr;
}

template <typename T>
class TreeNode {
public:
	T data;
	TreeNode* left;
	TreeNode* right;

	TreeNode(T val = T());
};

template <typename T>
class BST {
	TreeNode<T>* root;

	void destroyTree(TreeNode<T>* root);
	TreeNode<T>* minValNode(TreeNode<T>* node);
	TreeNode<T>* maxValNode(TreeNode<T>* node);
	bool ancestors(TreeNode<T>* root, T key, vector<T> result);

public:
	BST(T val = T());
	TreeNode<T>* getRoot();
	TreeNode<T>* insert(TreeNode<T>* root, T val);
	void PreOT(TreeNode<T>* root);
	TreeNode<T>* deleteNode(TreeNode<T>* root, T val);
	TreeNode<T>* findInorderSuccessor(TreeNode<T>* root, T key);
	TreeNode<T>* findInorderPredecessor(TreeNode<T>* root, T key);
	T findRange(TreeNode<T>* root);
	int findLeafNodes(TreeNode<T>* root);
	int findNonLeafNodes(TreeNode<T>* root);
	int findTotalNodes(TreeNode<T>* root);
	int maxDepth(TreeNode<T>* root);
	int findDepth(TreeNode<T>* root, T key);
	TreeNode<T>* mirror(TreeNode<T>* root);
	void ancestors(TreeNode<T>* root, T key);
	TreeNode<T>* getParent(TreeNode<T>* root, T key, TreeNode<T>* parent = nullptr);
	TreeNode<T>* lowestCommonAncestor(TreeNode<T>* root, T key1, T key2);
	void kthSmallest(TreeNode<T>* node, int k, T result);
	~BST();
};

template <typename T>
TreeNode<T>::TreeNode(T val) : left(nullptr), right(nullptr) {
	this->data = val;
}

template <typename T>
BST<T>::BST(T val) : root(nullptr) {
	if (root == nullptr) {
		TreeNode<T>* newNode = new TreeNode<T>(val);
		root = newNode;
	}
}

template <typename T>
TreeNode<T>* BST<T>::getRoot() {
	return this->root;
}

template <typename T>
void BST<T>::destroyTree(TreeNode<T>* root) {
	if (root != nullptr) {
		destroyTree(root->left);
		destroyTree(root->right);
		delete root;
	}
}

template <typename T>
TreeNode<T>* BST<T>::minValNode(TreeNode<T>* node) {
	if (node == nullptr || root->left == nullptr) {
		return root;
	}

	if (node->left != nullptr) {
		return minValNode(node->left);
	}
}

template <typename T>
TreeNode<T>* BST<T>::maxValNode(TreeNode<T>* node) {
	if (node == nullptr || root->right == nullptr) {
		return root;
	}

	if (node->right != nullptr) {
		return maxValNode(node->right);
	}
}

template <typename T>
bool BST<T>::ancestors(TreeNode<T>* root, T key, vector<T> result) {
	if (root == nullptr) {
		return false;
	}
	else if (key < root->data) {
		result.push_back(root->data);
		return ancestors(root->left, key, result);
	}
	else if (key > root->data) {
		result.push_back(root->data);
		return ancestors(root->right, key, result);
	}
	else {
		return true;
	}
}

template <typename T>
TreeNode<T>* BST<T>::insert(TreeNode<T>* root, T val) {
	if (root == nullptr) {
		root = new TreeNode<T>(val);
	}
	else if (val < root->data) {
		root->left = insert(root->left, val);
	}
	else {
		root->right = insert(root->right, val);
	}
	return root;
}

template <typename T>
void BST<T>::PreOT(TreeNode<T>* root) {
	if (root == nullptr) {
		return;
	}
	PreOT(root->left);
	cout << root->data << " ";
	PreOT(root->right);
}

template <typename T>
TreeNode<T>* BST<T>::deleteNode(TreeNode<T>* root, T val) {
	if (root == nullptr) {
		return root;
	}
	else if (val < root->data) {
		root->left = deleteNode(root->left, val);
	}
	else if (val > root->data) {
		root->right = deleteNode(root->right, val);
	}
	else {
		if (root->left == nullptr) {
			TreeNode<T>* temp = root->right;
			delete root;
			return temp;
		}
		else if (root->right == nullptr) {
			TreeNode<T>* temp = root->left;
			delete root;
			return temp;
		}
		else {
			TreeNode<T>* temp = minValNode(root->right);
			root->data = temp->data;
			root->right = deleteNode(root->right, temp->data);
		}
	}
	return root;
}

template <typename T>
TreeNode<T>* BST<T>::findInorderSuccessor(TreeNode<T>* root, T key) {
	if (root == nullptr) {
		return nullptr;
	}

	if (key < root->data) {
		TreeNode<T>* leftSuccessor = findInorderSuccessor(root->left, key);
		return (leftSuccessor != nullptr) ? leftSuccessor : root;
	}
	else if (key > root->data) {
		return findInorderSuccessor(root->right, key);
	}
	else {
		if (root->right != nullptr) {
			return minValNode(root->right);
		}
		else {
			return nullptr;
		}
	}
}

template <typename T>
TreeNode<T>* BST<T>::findInorderPredecessor(TreeNode<T>* root, T key) {
	if (root == nullptr) {
		return nullptr;
	}

	if (key < root->data) {
		TreeNode<T>* predeccessor = findInorderPredecessor(root->left, key);
		return (predeccessor != nullptr) ? predeccessor : root;
	}
	else if (key > root->data) {
		return findInorderPredecessor(root->right, key);
	}
	else {
		if (root->left != nullptr) {
			return maxValNode(root->left);
		}
		else {
			return nullptr;
		}
	}
}

template <typename T>
T BST<T>::findRange(TreeNode<T>* root) {
	TreeNode<T>* max = maxValNode(root);
	TreeNode<T>* min = minValNode(root);
	return max->data - min->data;
}

template <typename T>
int BST<T>::findLeafNodes(TreeNode<T>* root) {
	if (root == nullptr) {
		return 0;
	}
	else {
		if (root->left == nullptr  root->right == nullptr) {
			return 1;
		}
		else {
			return findLeafNodes(root->left) + findLeafNodes(root->right);
		}
	}
}

template <typename T>
int BST<T>::findNonLeafNodes(TreeNode<T>* root) {
	if (root == nullptr) {
		return 0;
	}
	else {
		if (root->left != nullptr || root->right != nullptr) {
			return 1 + findNonLeafNodes(root->left) + findNonLeafNodes(root->right);
		}
		else {
			return findNonLeafNodes(root->left) + findNonLeafNodes(root->right);
		}
	}
}

template <typename T>
int BST<T>::findTotalNodes(TreeNode<T>* root) {
	if (root == nullptr) {
		return 0;
	}
	else {
		return findLeafNodes(root) + findNonLeafNodes(root);
	}
}

template <typename T>
int BST<T>::maxDepth(TreeNode<T>* root) {
	if (root == nullptr) {
		return 0;
	}
	else {
		int leftDepth = maxDepth(root->left);
		int rightDepth = maxDepth(root->right);
		if (leftDepth > rightDepth) {
			return 1 + leftDepth;
		}
		else {
			return 1 + rightDepth;
		}
	}
}

template <typename T>
int BST<T>::findDepth(TreeNode<T>* root, T key) {
	if (root == nullptr) {
		return -1; // Key not found
	}
	else if (root->data == key) {
		return 0;
	}
	else if (key < root->data) {
		int leftDepth = findDepth(root->left, key);
		return (leftDepth == -1) ? -1 : 1 + leftDepth;
	}
	else {
		int rightDepth = findDepth(root->right, key);
		return (rightDepth == -1) ? -1 : 1 + rightDepth;
	}
}

template <typename T>
TreeNode<T>* BST<T>::mirror(TreeNode<T>* root) {
	if (root == nullptr) {
		return root;
	}
	else {
		TreeNode<T>* temp = root->left;
		root->left = mirror(root->right);
		root->right = mirror(temp);
	}

	return root;
}

template <typename T>
void BST<T>::ancestors(TreeNode<T>* root, T key) {
	vector<T> result;
	if (ancestors(root, key, result)) {
		cout << "Ancestors of " << key << " are:\n";
		if (!result.empty()) {
			for (auto i : result) {
				cout << i << " ";
			}
			cout << "\n";
		}
		else {
			cout << "NULL\n";
		}
	}
	else {
		cout << "Key not found\n";
	}
}
template <typename T>
TreeNode<T>* BST<T>::getParent(TreeNode<T>* root, T key, TreeNode<T>* parent) {
	if (root == nullptr) {
		return nullptr;
	}
	if (root->data == key) return parent;

	if (key < root->data) {
		return getParent(root->left, key, root);
	}
	else {
		return getParent(root->right, key, root);
	}
}

template <typename T>
TreeNode<T>* BST<T>::lowestCommonAncestor(TreeNode<T>* root, T key1, T key2) {
	if (root == nullptr) {
		return nullptr;
	}

	if (key1 < root->data  key2 < root->data) {
		return lowestCommonAncestor(root->left, key1, key2);
	}
	else if (key1 < root->data  key2 > root->data) {
		return lowestCommonAncestor(root->right, key1, key2);
	}
	else {
		return root;
	}
}

template <typename T>
void BST<T>::kthSmallest(TreeNode<T>* node, int k, T result) {
	if (node == nullptr || k == 0) {
		return;
	}

	kthSmallest(node->left, k, result);
	k--;
	if (k == 0) {
		result = node->data;
		return;
	}

	kthSmallest(node->right, k, result);
}

template <typename T>
BST<T>::~BST() {
	destroyTree(root);
}



#endif