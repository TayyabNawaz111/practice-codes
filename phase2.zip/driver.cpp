#include "data_structures"
int main()
{
        BST tree;
		int choice;
		string key;

		do {
			// Display the menu
			cout << "Menu:\n";
			cout << "1) Delete a record\n"; //done
			cout << "2) update email address\n"; //done
			
			cout << "4) update home phone\n"; //done
			cout << "5) Add/update record\n";//done
			cout << "6) Print specific record\n"; //done
			cout << "7) Print all students\n"; //done
			cout << "8) update Work phone\n"; //done
			cout << "9) Quit\n";
			cout << "Enter your choice: ";
			cin >> choice;

			if (choice == 1) {
				cout << "Enter KEY for deletion: ";
				cin >> key;
				tree.deleteNode(tree.root,key);
			}
			else if (choice == 2) {
				cout << "Enter KEY for email update: ";
				cin.ignore();
				cin >> key;
				string newEmail;
				cout << "Enter new email: ";
				cin.ignore();
				getline(cin, newEmail);
				tree.updateEmail(tree.root, key , newEmail);
			}
			
			else if (choice == 4) {
				cout << "Enter KEY for Home phone update: ";
				cin.ignore();
				cin >> key;
				string newHomePhone;
				cout << "Enter new phone number: ";
				cin.ignore();
				getline(cin, newHomePhone);
				tree.UpdateHomePhone(tree.root, key, newHomePhone);
			}
			else if (choice == 5) {
				string lastName;
				string firstName;
				string middleInitial;
				string key;
				string major;
				string year;
				string email;
				string homePhone;
				string workPhone;
				cout << "Enter Last name: ";
				cin.ignore();
				getline(cin, lastName);
				cout << "Enter First name: ";
				cin.ignore();
				getline(cin, firstName);
				cout << "Enter Middle Initial: ";
				cin.ignore();
				getline(cin, middleInitial);
				cout << "Enter key: ";
				cin.ignore();
				getline(cin, key);
				cout << "Enter Major: ";
				cin.ignore();
				getline(cin, major);
				cout << "Enter year: ";
				cin.ignore();
				getline(cin, year);
				cout << "Enter email: ";
				cin.ignore();
				getline(cin, email);
				cout << "Enter Home phone: ";
				cin.ignore();
				getline(cin, homePhone);
				cout << "Enter work phone: ";
				cin.ignore();
				getline(cin, workPhone);
				Student newStudent(lastName, firstName, middleInitial, key, major, year, email, homePhone, workPhone);
				tree.insert(tree.root, newStudent);
			}
			else if (choice == 6) {
				cout << "Enter KEY for display: ";
				cin >> key;
				tree.findRecord(tree.root, key);
			}
			else if (choice == 7) {
			    tree.printSorted();
			}
			else if (choice == 8) {
				cout << "Enter KEY for work phone update: ";
				cin >> key;
				string workPhone;
				cout << "Enter work phone: ";
				cin.ignore();
				getline(cin, workPhone);
				tree.UpdateWorkPhone(tree.root,key, workPhone);

			}
			else if (choice == 9) {
				cout << "Quitting....\n";
				tree.~BST();

			}
			else {
				cout << "Invalid choice. Try again.\n";
			}

		} while (choice != 9);
	}