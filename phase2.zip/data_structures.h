#include <iostream>
#include "stdent.h"
using namespace std;

class Node {
public:
	Student key;
	Node *left, *right;
	Node(Student key):left(NULL),right(NULL){
		this->key = key;
	}
};


class BST{
	Node *root;
public:
	BST(){}
	// Inorder Traversal
	void inorder(Node *root) {
		if (root != NULL) {
			inorder(root->left);

			root->key.displayRecord();

			inorder(root->right);
		}
	}

	// Insert a Node
	Node *insert(Node *root, Student key) {
		if (root == NULL) return new Node(key);

		if (key.getKey() < root->key.getKey())
			root->left = insert(root->left, key);
		else
			root->right = insert(root->right, key);

		return root;
	}

	Node *minValueNode(Node *root) {
		Node *current = root;

		while (current && current->left != NULL)
			current = current->left;

		return current;
	}

	// Deleting a Node
	Node *deleteNode(Node *root, string key) {
		if (root == NULL) return root;

		if (key.getKey() < root->key.getKey())
			root->left = deleteNode(root->left, key);
		else if (key.getKey() > root->key.getKey())
			root->right = deleteNode(root->right, key);
		else {
			if (root->left == NULL) {
				Node *temp = root->right;
				delete root;
				return temp;
			}
			else if (root->right == NULL) {
				Node *temp = root->left;
				delete root;
				return temp;
			}

			Node *temp = minValueNode(root->right);

			root->key = temp->key;

			root->right = deleteNode(root->right, temp->key);
		}
		return root;
	}

	void updateHomePhone(Node *root, string key, string newPhone){
		if (root == nullptr) return;
		else{
			if (key < root->key.getKey()){
				updateHomePhone(root->left, key, newPhone);
			}
			else if (key > root->key.getKey()){
				updateHomePhone(root->right, key, newPhone);
			}
			else{
				root->key.setHomePhone(newPhone);
			}
		}
	}
void updateEmail(Node *root, string key, string newEmail{
		if (root == nullptr) return;
		else{
			if (key < root->key.getKey()){
				updateEmail(root->left, key, newEmail);
			}
			else if (key > root->key.getKey()){
				updateEmail(root->right, key, newEmail);
			}
			else{
				root->key.setEmail(newEmail);
			}
		}
	}

	void updateWorkPhone(Node *root, string key, string newPhone){
		if (root == nullptr) return;
		else{
			if (key < root->key.getKey()){
				updateWorkPhone(root->left, key, newPhone);
			}
			else if (key > root->key.getKey()){
				updateWorkPhone(root->right, key, newPhone);
			}
			else{
				root->key.setWorkPhone(newPhone);
			}
		}
	}
	
	void findRecord(Node *root , string key){
	    if(root==nullptr) {
	        cout<<"No record found\n";
	        return;
	    }
	    else{
	        if(key<root->key.getKey()){
	            findRecord(root->left,key);
	        }
	        else if(key>root->key.getKey()){
	            findRecord(root->right,key);
	        }
	        else{
	            cout<<"Record found\n";
	            root->key.displayRecord();
	        }
	    }
	}
	void printSorted(){
	    inorder(this->root);
	}
	
	void destroyTree(Node *root){
	    if(root==nullptr)return;
	    else{
	        destroyTree(root->left);
	        destroyTree(root->right);
	        delete root;
	    }
	}
	~BST(){
	    destroyTree(this->root);
	}
	
};