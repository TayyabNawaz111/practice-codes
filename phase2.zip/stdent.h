#ifndef STUDENT_H
#define STUDENT_H
#include <iostream>
#include <string>
using namespace std;
class Student {
public:
	string lastName;
	string firstName;
	string middleInitial;
	string key;
	string major;
	string year;
	string email;
	string homePhone;
	string workPhone;
	//constructor
	Student(){}
	Student(string last, string first, string middle,
		string studentKey, string studentMajor, string studentYear,
		string studentEmail, string studentHomePhone, string studentWorkPhone)
		: lastName(last),
		firstName(first),
		middleInitial(middle),
		key(studentKey),
		major(studentMajor),
		year(studentYear),
		email(studentEmail),
		homePhone(studentHomePhone),
		workPhone(studentWorkPhone) {}
	// Getter functions
	string getLastName()const {
		return lastName;
	}

	string getFirstName() const{
		return firstName;
	}

	string getMiddleInitial() const{
		return middleInitial;
	}

	string getKey() const{
		return key;
	}

	string getMajor() const{
		return major;
	}

	string getYear() const{
		return year;
	}

	string getEmail() const{
		return email;
	}

	string getHomePhone() const{
		return homePhone;
	}

	string getWorkPhone() const{
		return workPhone;
	}

	// Setter functions
	void setLastName(string value)  {
		lastName = value;
	}

	void setFirstName(string value)  {
		firstName = value;
	}

	void setMiddleInitial(string value) {
		middleInitial = value;
	}

	void setKey(string value) {
		key = value;
	}

	void setMajor(string value) {
		major = value;
	}

	void setYear(string value) {
		year = value;
	}

	void setEmail(string value) {
		email = value;
	}

	void setHomePhone(string value) {
		homePhone = value;
	}

	void setWorkPhone(string value) {
		workPhone = value;
	}

	// Display function
	void displayRecord()  {
		cout << "Last Name: " << lastName << "\nFirst Name: " << firstName << "\nMiddle Initial: "
			<< middleInitial << "\nKey: " << key << "\nMajor: " << major << "\nYear: "
			<< year << "\nEmail: " << email << "\nHome Phone: " << homePhone
			<< "\nWork Phone: " << workPhone << "\n\n";
	}
};
#endif