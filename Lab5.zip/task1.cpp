/*
#include <iostream>
using namespace std;
//Function to take input from user
void takeInput(double &num1, double &num2) {
	cout << "Enter the value of num1: ";
	cin >> num1;
	cout << "Enter the value of num2: ";
	cin >> num2;
}

class Calculator {
public:
	double add(double num1, double num2) {
		return num1 + num2;
	}	double subtract(double num1, double num2) {
		return num1 - num2;
	}	double multiply(double num1, double num2) {
		return num1 * num2;
	}	double divide(double num1, double num2) {
		while (num2 == 0) {
			cout << "Value of num2 cannot be zero. Enter the non zero value of num2: ";
			cin >> num2;
		}
		return num1 / num2;
	}
};
int main() {
	//take input from user
	double num1, num2;
	takeInput(num1, num2);
	Calculator c;
	//menu
	cout << "----------------------------\n";
	cout << "Press 1 for addition\n";
	cout << "Press 2 for subtraction\n";
	cout << "Press 3 for multiplication\n";
	cout << "Press 4 for division\n";
	cout << "----------------------------\n";
	cout << "Enter your choice: ";
	int choice;
	cin >> choice;
	cout << "----------------------------\n";
	if (choice == 1) {
		cout << "Result: "<< c.add(num1, num2) << endl;
	}
	else if (choice == 2) {
		cout << "Result: " << c.subtract(num1, num2) << endl;
	}

	else if (choice == 3) {
		cout << "Result: " << c.multiply(num1, num2) << endl;
	}

	else if (choice == 4) {
		cout << "Result: " << c.divide(num1, num2) << endl;
	}
	else {
		cout << "Invalid Choice\n";
	}
	cout << "----------------------------\n";
	system("pause");
	return 0;
}
*/