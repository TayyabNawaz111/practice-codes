/*
#include <iostream>
#include <string>
using namespace std;
class Employee {
private:
	string name;
	double salary;
public:
	//Constructor
	Employee(string empName, double empSalary) {
		this->name = empName;
		this->salary = empSalary;
	}
	//Getter
	string getName() {
		return this->name;
	}

	double getSalary() {
		return this->salary;
	}
	//Annual Salary Calculator Function
	double calculateAnnualSalary() {
		return this->salary * 12;
	}

	//Display Function
	void displayEmployeeDetails() {
		cout << "Employee Name: " << this->name << endl;
		cout << "Monthly Salary: $" << this->salary << endl;
		cout << "Annual Salary: $" << this->calculateAnnualSalary() << endl;
	}
};

int main() {

	Employee emp1("Tayyab", 5000); 
	emp1.displayEmployeeDetails();
	cout << "----------------------------\n";


	Employee emp2("Ubaid Ullah", 6000);
	emp2.displayEmployeeDetails();
	cout << "----------------------------\n";

	system("pause");  
	return 0;
}
*/