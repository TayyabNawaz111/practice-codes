#include <iostream>
#include <string>
using namespace std;

class Product {
private:
	string name;
	double price;
	int quantity;

public:
	// Constructor
	Product(string n, double p, int q) : name(n), price(p), quantity(q) {}

	// Getter methods
	string getName()  {
		return name;
	}
	double getPrice()  {
		return price;
	}
	int getQuantity()  {
		return quantity; 
	}

	// Method to update the stock quantity
	void updateQuantity(int newQuantity) {
		quantity = newQuantity;
	}

	// Method to check if stock is low
	bool isLowStock()  {
		return quantity < 5;
	}

	// Method to display product details
	void displayProduct()  {
		cout << "Product: " << name << ", Price: $" << price
			<< ", Quantity: " << quantity << endl;
	}
};

class Inventory {
private:
	Product* products[5];
	int productCount;

public:
	// Constructor
	Inventory() : productCount(0) {}

	// Method to add a new product to inventory
	void addProduct(string name, double price, int quantity) {
		if (productCount < 5) {
			products[productCount] = new Product(name, price, quantity);
			productCount++;
			cout << "Product added successfully!" << endl;
		}
		else {
			cout << "Inventory is full! Cannot add more products." << endl;
		}
	}

	// Method to update stock of an existing product
	void updateStock(string productName, int newQuantity) {
		for (int i = 0; i < productCount; i++) {
			if (products[i]->getName() == productName) {
				products[i]->updateQuantity(newQuantity);
				cout << "Stock updated for " << productName << endl;
				return;
			}
		}
		cout << "Product not found!" << endl;
	}

	// Method to check for low stock items
	void checkLowStock() {
		cout << "\nLow stock items (quantity less than 5):\n";
		bool foundLowStock = false;
		for (int i = 0; i < productCount; i++) {
			if (products[i]->isLowStock()) {
				products[i]->displayProduct();
				foundLowStock = true;
			}
		}
		if (!foundLowStock) {
			cout << "No low stock items found." << endl;
		}
	}

	// Method to display all products in the inventory
	void displayInventory() {
		cout << "\nInventory:\n";
		for (int i = 0; i < productCount; i++) {
			products[i]->displayProduct();
		}
	}
};

int main() {
	Inventory inventory;

	// Add some products to the inventory
	inventory.addProduct("Laptop", 1000.00, 10);
	inventory.addProduct("Smartphone", 500.00, 3);  
	inventory.addProduct("Headphones", 150.00, 7);
	inventory.addProduct("Keyboard", 80.00, 20);
	inventory.addProduct("Mouse", 25.00, 2);  

	// Display inventory
	cout << "------------------------------\n";
	inventory.displayInventory();

	// Check for low stock items
	cout << "------------------------------\n";
	inventory.checkLowStock();

	// Update stock of an existing product
	cout << "------------------------------\n";
	inventory.updateStock("Smartphone", 8);

	// Display inventory again after stock update
	cout << "------------------------------\n";
	inventory.displayInventory();
	cout << "------------------------------\n";
	system("pause");
	return 0;
}
