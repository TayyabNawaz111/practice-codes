/*
#include <iostream>
#include <string>
using namespace std;

class Student {
private:
	string name;
	string studentID;
	double grades[3]; 
	double average = 0;

public:
	// Constructor
	Student(string n, string id) {
		this->name = n;
		this->studentID = id;
	}

	// Method to input grades for each assessment
	void inputGrades() {
		cout << "Enter grades for " << name << " (" << studentID << "):\n";
		for (int i = 0; i < 3; i++) {
			// Loop until the user enters valid marks
			do {
				cout << "Assessment " << (i + 1) << " Marks (out of 100): ";
				cin >> grades[i];
				if (grades[i] < 0 || grades[i] > 100) {
					cout << "Invalid marks. Please enter a value between 0 and 100.\n";
				}
			} while (grades[i] < 0 || grades[i] > 100);  
		}
	}

	// Method to calculate the average grade
	void calculateAverage() {
		double sum = 0;
		for (int i = 0; i < 3; i++) {
			sum += grades[i];
		}
		average = sum / 3;
	}

	// Method to assign a letter grade based on the average score
	string getLetterGrade() {
		if (average >= 90) return "A";
		if (average >= 80) return "B";
		if (average >= 70) return "C";
		if (average >= 60) return "D";
		return "F";
	}

	// Method to display student details and grade
	void displayStudentDetails() {
		cout << "\nStudent Name: " << name << endl;
		cout << "Student ID: " << studentID << endl;
		cout << "Average Grade: " << average << endl;
		cout << "Letter Grade: " << getLetterGrade() << endl;
	}
};

int main() {
	string name, studentID;

	// Get student details
	cout << "Enter student name: ";
	getline(cin, name);
	cout << "Enter student ID: ";
	getline(cin, studentID);

	// Create Student object
	Student student(name, studentID);

	// Input grades
	student.inputGrades();

	// Calculate average
	student.calculateAverage();

	// Display student details and grade
	cout << "--------------------------------------";
	student.displayStudentDetails();
	cout << "--------------------------------------\n";
	system("pause");
	return 0;
}
*/