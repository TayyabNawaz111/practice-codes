/*

#include <iostream>
#include <string>
using namespace std;

class Order {
private:
	string product;
	double price;
	int quantity;

public:
	// Constructor
	Order() {
		product = "Laptop";
		price = 200;
	}
	//setter for quantity
	void setQuantity(int quantity){
		this->quantity = quantity;
	}
	// Method to calculate total price
	double calculateTotal()  {
		return price * quantity;
	}
	//Method to display Product details
	void productDetails(){
		cout << "Product: " << product << endl;
		cout << "Product price: $" << price << endl;
	}

	// Method to display order details
	void displayOrder()  {
		cout << "Total price: $" << calculateTotal() << endl;
	}
};

int main() {
	
	int productQuantity;
	Order order;
	//Display detail
	order.productDetails();
	// Ask user for the quantity of the product
	cout << "Enter the quantity: ";
	cin >> productQuantity;
	order.setQuantity(productQuantity);
	// Display the order details
	order.displayOrder();
	system("pause");
	return 0;
}

*/