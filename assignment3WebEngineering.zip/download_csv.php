<?php
header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="data.csv"');

$output = fopen('php://output', 'w');

$conn = new mysqli("localhost", "root", "", "assignment 3");

if ($conn->connect_error) {
    echo "Connection failed<br>";
} else {
    $sql = 'SELECT * FROM person';
    $result = $conn->query($sql);

    if ($result === FALSE) {
        echo "Error executing query<br>";
    } else {
        if ($result->num_rows > 0) {
            $header = array('ID', 'First', 'Last', 'Email', 'Phone', 'Location', 'Hobby');
            fputcsv($output, $header);
            while ($row = $result->fetch_assoc()) {
                fputcsv($output, $row);
            }
        }
    }
}
fclose($output);
$conn->close();
?>
