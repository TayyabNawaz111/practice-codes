<?php
if ($_SERVER["REQUEST_METHOD"] == "POST"){
    $conn = new mysqli("localhost", "root", "", "assignment 3");
    $id = $_REQUEST['id'];
    $first_name = $_REQUEST['first_name'];
    $last_name = $_REQUEST['last_name'];
    $email = $_REQUEST['email'];
    $phone = $_REQUEST['phone'];
    $location = $_REQUEST['location'];
    $hobby = $_REQUEST['hobby'];
    $sql = "UPDATE person SET First='$first_name', Last='$last_name', Email='$email', Phone='$phone' , Location = '$location' , Hobby='$hobby'
    WHERE ID='$id'";
    ($conn->query($sql));
    $conn->close();
    header("location: show.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Edit Page</title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <style>
        a{
            text-decoration: none !important;
        }
       
        div {
            margin-top: 50px;
        }
        
        .doneBtn,button{
            padding-bottom:30px !important;
        }

        table {
            width: 100%;
            margin-bottom: 10px;
        }
        .addBtn {
            background-color: rgb(29, 204, 29);
            border-radius: 4px;
            color: white;
            height: 25px;
            cursor: pointer;
        }
        .csvBtn {
            background-color: rgb(38, 131, 237);
            border-radius: 4px;
            color: white;
            height: 25px;
            cursor: pointer;
        }
        .editBtn {
            background-color: yellow;
            border-radius: 4px;
            height: 25px;
            cursor: pointer;
        }
        .delBtn {
            background-color: rgb(240, 45, 45);
            border-radius: 4px;
            color: white;
            height: 25px;
            cursor: pointer;
        }
        .doneBtn {
            border-radius: 4px;
            color: white;
            height: 25px;
            cursor: pointer;
        }
        .table-striped tbody tr:not(:hover) {
    background-color: rgba(0, 0, 0, 0) !important;
}
        tr:hover {
            background-color: #cdcccc; 
        }
    </style>
</head>
<body>
    <div class="container">
        <table class="table  table-striped">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>First</th>
                    <th>Last</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Location</th>
                    <th>Hobby</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php 
            if(isset($_REQUEST['id'])){ 
             $id= $_REQUEST['id'];
// Create connection
$conn = new mysqli("localhost", "root", "", "assignment 3");

// Check connection
if ($conn->connect_error) {
    echo "Connection failed<br>";
} else {
    $sql = 'SELECT * FROM person';
    $result = $conn->query($sql);

    if ($result === FALSE) {
        echo "Error executing query<br>";
    } 
    if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                if ($row['ID'] !== $id) {
                    echo "<tr>";
                    echo "<td>" . $row['ID'] . "</td>";
                    echo "<td>" . $row['First'] . "</td>";
                    echo "<td>" . $row['Last'] . "</td>";
                    echo "<td>" . $row['Email'] . "</td>";
                    echo "<td>" . $row['Phone'] . "</td>";
                    echo "<td>" . $row['Location'] . "</td>";
                    echo "<td>" . $row['Hobby'] . "</td>";
                    echo "<td>
                           <a href='show.php'><button class='btn btn-warning editBtn'>Edit</button></a>
                           <a href='delete.php?id=$row[ID]'><button class='btn btn-danger delBtn'>Del</button></a>
                         </td>";
                    echo "</tr>";
               }
        
                else {
                    echo "<form action='edit.php' method='post'>";
                    echo '<tr>';
                    echo '<td><input type="text" readonly name="id" value="' . $row['ID'] . '"></td>';  
                    echo "<td><input type='text' name='first_name' placeholder='First Name' value='" . $row["First"] . "' autofocus></td>";
                    echo "<td><input type='text' name='last_name' placeholder='Last Name' value='" . $row["Last"] . "'></td>";
                    echo "<td><input type='email' name='email' placeholder='Email'value='" . $row["Email"] . "'></td>";
                    echo "<td><input type='text' name='phone' placeholder='Phone'value='" . $row["Phone"] . "'></td>";
                    echo "<td><input type='text' name='location' placeholder='Location'value='" . $row["Location"] . "'></td>";
                    echo "<td><input type='text' name='hobby' placeholder='Hobby' value='" . $row["Hobby"] . "'></td>";
                    echo "<td>
                    <input type = 'submit' value = 'Done' class='btn btn-success doneBtn'>
                    </td>";
                    echo '</tr>';
                    echo "</form>";                    
            }
        } 
    }else {
            echo "<tr><td colspan='8'>No data found</td></tr>";
        }
    }
}
  
?>


            </tbody>
        </table>
        <a href="download_csv.php"><button class="btn btn-primary csvBtn">Download CSV</button></a>
        <a href="add.php"><button class="btn btn-success addBtn" id="add">Add Item</button></a>
    </div>

    </div>


</body>
</html>
