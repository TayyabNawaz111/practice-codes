<?php
$id  = $_REQUEST['id'];
$conn = new mysqli("localhost", "root", "", "assignment 3");

if ($conn->connect_error) {
    echo "Connection failed<br>";
} else {
    $sql = "DELETE FROM person WHERE ID = '$id'";
    $conn->query($sql);
}
header("Location: show.php");
?>