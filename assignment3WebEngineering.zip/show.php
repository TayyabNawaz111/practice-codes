<!DOCTYPE html>
<html lang="en">
<head>
    <title>Content</title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <style>
        a{
            text-decoration: none !important;
        }
        div {
            margin-top: 50px;
        }
        
        button{
            padding-bottom:30px !important;
        }

        table {
            width: 100%;
            margin-bottom: 10px;
        }
        .addBtn {
            background-color: rgb(29, 204, 29);
            border-radius: 4px;
            color: white;
            height: 25px;
            cursor: pointer;
        }
        .csvBtn {
            background-color: rgb(38, 131, 237);
            border-radius: 4px;
            color: white;
            height: 25px;
            cursor: pointer;
        }
        .editBtn {
            background-color: yellow;
            border-radius: 4px;
            height: 25px;
            cursor: pointer;
        }
        .delBtn {
            background-color: rgb(240, 45, 45);
            border-radius: 4px;
            color: white;
            height: 25px;
            cursor: pointer;
        }
        .table-striped tbody tr:not(:hover) {
    background-color: rgba(0, 0, 0, 0) !important;
}
        tr:hover {
            background-color: #cdcccc; 
        }
    </style>
</head>
<body>
    <div class="container">
        <table class="table  table-striped">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>First</th>
                    <th>Last</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Location</th>
                    <th>Hobby</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php

// Create connection
$conn = new mysqli("localhost", "root", "", "assignment 3");

// Check connection
if ($conn->connect_error) {
    echo "Connection failed<br>";
} else {
    $sql = 'SELECT * FROM person';
    $result = $conn->query($sql);

    if ($result === FALSE) {
        echo "Error executing query<br>";
    } 
    if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row['ID'] . "</td>";
                echo "<td>" . $row['First'] . "</td>";
                echo "<td>" . $row['Last'] . "</td>";
                echo "<td>" . $row['Email'] . "</td>";
                echo "<td>" . $row['Phone'] . "</td>";
                echo "<td>" . $row['Location'] . "</td>";
                echo "<td>" . $row['Hobby'] . "</td>";
                echo "<td>
               <a href='edit.php?id=$row[ID]'> <button class='btn btn-warning editBtn'>Edit</button> </a> 
                <a href='delete.php?id=$row[ID]'><button class='btn btn-danger delBtn'>Del</button></a>
            </td>";
              echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='8'>No data found</td></tr>";
        }
    

}
$conn->close();
?>


            </tbody>
        </table>
        <a href="download_csv.php"><button class="btn btn-primary csvBtn">Download CSV</button></a>
        <a href="add.php"><button class="btn btn-success addBtn" id="add">Add Item</button></a>
    </div>

    </div>


</body>
</html>
