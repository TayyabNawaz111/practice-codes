<?php
if ($_SERVER["REQUEST_METHOD"] == "POST"){
    $conn = new mysqli("localhost", "root", "", "assignment 3");

    if ($conn->connect_error) {
        echo "Connection failed<br>";
    } else {
        $id = $_REQUEST['id'];
        $first_name = $_REQUEST['first_name'];
        $last_name = $_REQUEST['last_name'];
        $email = $_REQUEST['email'];
        $phone = $_REQUEST['phone'];
        $location = $_REQUEST['location'];
        $hobby = $_REQUEST['hobby'];
        // Insert data into the database
        $insertQuery = "INSERT INTO person (ID, First, Last, Email, Phone, Location, Hobby) 
         VALUES ('$id', '$first_name', '$last_name', '$email', '$phone', '$location', '$hobby')";
         $conn->query($insertQuery);
    }
    $conn->close();
    header("Location: show.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Details</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <style>
        div {
            margin-top: 50px;
        }

        .btn {
            padding-bottom: 30px !important;
        }

        table {
            width: 100%;
            margin-bottom: 10px;
        }

        .addBtn {
            background-color: rgb(29, 204, 29);
            border-radius: 4px;
            color: white;
            height: 25px;
            cursor: pointer;
        }

        .csvBtn {
            background-color: rgb(38, 131, 237);
            border-radius: 4px;
            color: white;
            height: 25px;
            cursor: pointer;
        }

        .editBtn {
            background-color: yellow;
            border-radius: 4px;
            height: 25px;
            cursor: pointer;
        }

        .delBtn {
            background-color: rgb(240, 45, 45);
            border-radius: 4px;
            color: white;
            height: 25px;
            cursor: pointer;
        }

        .table-striped tbody tr:not(:hover) {
            background-color: rgba(0, 0, 0, 0) !important;
        }

        tr:hover {
            background-color: #cdcccc;
        }
    </style>
</head>
<body>
    <div class="container">
        <table class="table  table-striped">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>First</th>
                    <th>Last</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Location</th>
                    <th>Hobby</th>
                </tr>
            </thead>
            <tbody>
              
        </form>
    </div>

    <?php
                $conn = new mysqli("localhost", "root", "", "assignment 3");

                if ($conn->connect_error) {
                    echo "Connection failed<br>";
                } else {
                    $sql = 'SELECT * FROM person';
                    $result = $conn->query($sql);

                    if ($result === FALSE) {
                        echo "Error executing query: " . $conn->error;
                    } else {
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo "<tr>";
                                echo "<td>" . $row['ID'] . "</td>";
                                echo "<td>" . $row['First'] . "</td>";
                                echo "<td>" . $row['Last'] . "</td>";
                                echo "<td>" . $row['Email'] . "</td>";
                                echo "<td>" . $row['Phone'] . "</td>";
                                echo "<td>" . $row['Location'] . "</td>";
                                echo "<td>" . $row['Hobby'] . "</td>";
                                echo "</tr>";
                            }
                        }
                    }
                }
                $conn->close();
                ?>

                <tr>
                    <form action="add.php" method="post">
                        <td><input type="text" name="id" placeholder="ID"></td>
                        <td><input type="text" name="first_name" placeholder="First Name"></td>
                        <td><input type="text" name="last_name" placeholder="Last Name"></td>
                        <td><input type="email" name="email" placeholder="Email"></td>
                        <td><input type="text" name="phone" placeholder="Phone"></td>
                        <td><input type="text" name="location" placeholder="Location"></td>
                        <td><input type="text" name="hobby" placeholder="Hobby"></td>
                </tr>
            </tbody>
        </table>
        <input type="submit" class="btn btn-success addBtn" id="add" value="Add Item">
    </form>
         
</body>
</html>
