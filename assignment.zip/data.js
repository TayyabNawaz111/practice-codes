const cars = [
    {
        id:1,
        company:"Suzuki",
        ac:true,
        model:2020
    },
    {
        id:2,
        company:"Honda",
        ac:true,
        model:2020
    },
    {
        id:3,
        company:"Toyota",
        ac:true,
        model:2020
    }
]
module.exports = cars;