const books = [
    {
        id: 1,
        title: "Book 1",
        author: "Tayyab Nawaz",
        genre: "fiction",
        year: 1977,
        available: true
    }, {
        id: 2,
        title: "Book 2",
        author: "Ubaid Ullah",
        genre: "non-fiction",
        year: 1957,
        available: false
    }, {
        id: 3,
        title: "Book 3",
        author: "Usama Rasheed",
        genre: "fiction",
        year: 1952,
        available: true
    }, {
        id: 4,
        title: "Book 4",
        author: "Azeem",
        genre: "fiction",
        year: 1990,
        available: true
    }, {
        id: 5,
        title: "Book 5",
        author: "Tayyab Shahzad",
        genre: "non-fiction",
        year: 2020,
        available: false
    }
]
module.exports = { books }