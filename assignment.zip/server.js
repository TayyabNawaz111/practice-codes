const cars = require("./data")
const express = require("express");
const app = express();
app.get('/', (req, res) => {
    res.send("Welcome to Car Shop");
})
app.get('/cars', (req, res) => {
    res.json(cars);
})
app.get('/suzuki', (req, res) => {
    res.json(cars.filter(car => car.company == "Suzuki"))
})
app.listen(8000, () => {
    console.log(`Server is listening on PORT 8000`);
})
