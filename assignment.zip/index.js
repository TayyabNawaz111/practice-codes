const { books } = require("./booksData")
const express = require("express");
const app = express();
app.get('/', (req, res) => {
    res.send("Welcome to Book Shop");
})
app.get('/api/books', (req, res) => {
    res.json(books);
})
app.get('/api/books/available', (req, res) => {
    res.json(books.filter(book => book.available));
})
app.get('/api/books/genre', (req, res) => {
    res.json(books.filter(book => book.genre === "fiction"));
})
app.get('/api/books/author', (req, res) => {
    res.json(books.filter(book => book.author === "Azeem"));
})
app.get('/api/books/year/before', (req, res) => {
    res.json(books.filter(book => book.year < 2000));
})
app.listen(8000, () => {
    console.log(`Server is listening on PORT 8000`);
})
