<?php
$conn = new mysqli("localhost", "root", "", "project");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_REQUEST['name'];
    $email = $_REQUEST['email'];
    $password = $_REQUEST['password'];
    $cpassword = $_REQUEST['cpassword'];

    $checkEmailQuery = "SELECT * FROM user WHERE id = '$email'";
    $result = $conn->query($checkEmailQuery);

    if ($result->num_rows > 0) {
        echo "Email already exists. Please choose a different one.";
    } elseif (empty($name) || empty($email) || empty($password) || empty($cpassword)) {
        echo "Please fill in all fields.";
    } elseif ($password != $cpassword) {
        echo "Passwords do not match.";
    } else {
        $insertUserQuery = "INSERT INTO user (id, pass) VALUES ('$email', '$password')";
        if ($conn->query($insertUserQuery) === TRUE) {
            echo "User registered successfully!";
            header("location:login.php");
        } else {
            echo "Error: " . $insertUserQuery . "<br>" . $conn->error;
        }
    }
}

$conn->close();
?>
