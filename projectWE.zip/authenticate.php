<?php
$email = $_REQUEST['email'];
$pass = $_REQUEST['pass'];

$conn = new mysqli("localhost", "root", "", "project");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM user WHERE id ='$email'";
$result = $conn->query($sql);

if ($result) {
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            if ($row['id'] == $email && $row['pass'] == $pass) {
                session_start();
                $_SESSION['id'] = $row['id'];
                header("location:dashboard.php");
                // echo "matched";
            } else {
                header("location:login.php");
                // echo " not matched";

            }
        }
    } else {
        header("location:login.php");
        // echo "no result";

    }
} else {
    echo "Error: " . $conn->error;
}

$conn->close();
?>
