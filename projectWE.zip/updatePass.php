<?php
$conn = new mysqli("localhost", "root", "", "project");


$email = $_REQUEST['email'];
$new_password = $_REQUEST['new_password'];

// Check if the email exists in the database
$emailCheckQuery = "SELECT * FROM user WHERE id = '$email'";
$result = $conn->query($emailCheckQuery);

if ($result->num_rows>0) {
    $updatePasswordQuery = "UPDATE user SET pass = '$new_password' WHERE id = '$email'";
    
    if ($conn->query($updatePasswordQuery) === TRUE) {
        echo "Password updated successfully";
        header("location:login.php");
    } else {
        echo "Error updating password: " . $conn->error;
    }
} else {
    // Email does not exist
    echo "Email not found in the database";
}

$conn->close();
?>
