
<?php
session_start();
$id = $_SESSION['id'];
$search = $_REQUEST["search"];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Email Inbox</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f4f4f4;
            padding: 20px;
            font-family: 'Arial', sans-serif;
        }

        h1 {
            color: #202124;
        }

        .email-container {
            margin-top: 20px;
        }

        .email {
            background-color: #ffffff;
            border: 1px solid #d1d1d1;
            border-radius: 10px;
            margin-bottom: 20px;
            padding: 20px;
            transition: transform 0.2s ease-in-out;
        }

        .email:hover {
            transform: scale(1.02);
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .email hr {
            margin: 10px 0;
            border-top: 1px solid #ddd;
        }

        .subject {
            font-size: 18px;
            color: #1565c0;
            margin-bottom: 10px;
        }

        .content {
            color: #333;
            line-height: 1.6;
        }
        input[type="text"] {
            width: 310px;
            border-radius :8px !important;
        }       
        .btn{
            width: auto !important;
            border-radius :17px !important;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="email-container">
            <h4>Search results are:</h4>
            <?php
                $conn = new mysqli("localhost", "root", "", "project");
                $sql = "SELECT * FROM user WHERE receiver = '$id' AND email LIKE '%$search%'";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        echo '<div class="email">';
                        echo '<div class="subject"><strong>Subject:</strong> ' . $row["subject"] . '</div>';
                        echo '<div class="content"><strong>Content:</strong><br>' . $row["email"] . '</div>';
                        echo '<hr>';
                        echo '</div>';
                    }
                }
                else{
                    echo "No email found <br>";
                }
            ?>
        </div>
    </div>

</body>
</html>


