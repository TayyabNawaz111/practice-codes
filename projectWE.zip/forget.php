
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="login.css" />
    <title>Password Reset Form</title>
</head>
<body>
    <div class="container" id="container">
        <div class="form-container log-in-container">
            <form action="updatePass.php" method="POST">
                <h1>Password Reset</h1>
                <input type="email" placeholder="Email" name="email" required/>
                <input type="password" placeholder="New Password" name="new_password" required/>
                <button type="submit">RESET PASSWORD</button>
            </form>
        </div>
        <div class="overlay-container">
            <div class="overlay">
                <div class="overlay-panel overlay-right">
                    <h1>HTML CSS Password Reset Form</h1>
                    <p>
                        This password reset form is created using pure HTML and CSS. For social
                        icons, FontAwesome is used.
                    </p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
