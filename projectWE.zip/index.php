<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Register Page</title>
    <link rel="stylesheet" href="register_style.css" />
  </head>
  <body>
    <div class="container">
      <div class="center">
        <h1>Register</h1>
        <form method="POST" action="addUser.php">
          <div class="txt_field">
            <input type="text" name="name" required placeholder="Name" />
            <span></span>
          </div>
          <div class="txt_field">
            <input type="email" name="email" required placeholder="Email"/>
            <span></span>
          </div>
          <div class="txt_field">
            <input type="password" name="password" required placeholder="Password"/>
            <span></span>
          </div>
          <div class="txt_field">
            <input type="password" name="cpassword" required placeholder="Confirm Password"/>
            <span></span>
          </div>
          <input name="submit" type="Submit" value="Sign Up" />
          <div class="signup_link">
            Have an Account ? <a href="login.php">Login Here</a>
          </div>
        </form>
      </div>
    </div>
  </body>
</html>
