<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="login.css" />

    <title>Login Form</title>
  </head>
  <body>
    <div class="container" id="container">
      <div class="form-container log-in-container">
        <form action="authenticate.php" method = "POST">
          <h1>Login</h1>
          <div class="social-container"></div>
          <input type="email" placeholder="Email" name = "email"/>
          <input type="password" placeholder="Password" name = "pass"/>
          <a href="forget.php">Forgot your password?</a>
          <button>LOG IN</button>
        </form>
      </div>
      <div class="overlay-container">
        <div class="overlay">
          <div class="overlay-panel overlay-right">
            <h1>HTML CSS Login Form</h1>
            <p>
              This login form is created using pure HTML and CSS. For social
              icons, FontAwesome is used.
            </p>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>
